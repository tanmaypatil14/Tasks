package com.filmCorporation.daoImpl;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import com.filmCorporation.dao.MovieDao;
import com.filmCorporation.model.Movie;
import com.filmCorporation.util.HibernateUtil;

public class MovieDaoImpl implements MovieDao {

	private static SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
	private static Session session = sessionFactory.openSession();

	public List<Movie> getMovieDetails(String language) {

		session.beginTransaction();

		Query query = session.createQuery("FROM Movie m WHERE m.language = :language");

		query.setParameter("language", language);

		List<Movie> movies = query.list();

		session.close();

		return movies;
	}

	public List<Movie> getMoviesForDirector(int directorId) {

		session.beginTransaction();

		Query query = session.createQuery("FROM Movie m WHERE m.director.directorId = :directorId");
		query.setParameter("directorId", directorId);
		List<Movie> movies = query.list();

		session.close();

		return movies;
	}

	public void addMovie(Movie movie) {

		session.beginTransaction();

		session.save(movie);

		if (movie.getLanguage().equals("English")) {
			String hqlQuery = "INSERT INTO Hollywood (movieName, language, releasedIn, revenueInDollars) "
					+ "SELECT movieName, language, releasedIn, revenueInDollars FROM Movie";

			Query query = session.createQuery(hqlQuery);
			int result = query.executeUpdate();

		}

		session.getTransaction().commit();
		System.out.println("Movie has been added successfully");
		session.close();

	}

	public void updateRevenue(int movieId) {

		session.beginTransaction();

		Movie movie1 = session.load(Movie.class, 1);
		movie1.setRevenueInDollars(100000);

		session.getTransaction().commit();

		session.close();
	}

	public List<String> getDistinctLanguages() {

		Query query = session.createQuery("SELECT DISTINCT m.language FROM Movie m");

		List<String> languageList = query.list();

		session.close();

		return languageList;
	}

	public List<Movie> getMovieAndDirectorName() {

		Query query = session.createQuery("FROM Movie");

		List<Movie> movieList = query.getResultList();

		for (Movie movie : movieList) {
			System.out
					.println("Movie: " + movie.getMovieName() + ", Director: " + movie.getDirector().getDirectorName());
		}
		session.close();

		return movieList;
	}

}
