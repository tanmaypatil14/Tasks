package com.AggregateFunction.util;

import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.service.ServiceRegistry;

import com.AggregateFunction.model.Director;
import com.AggregateFunction.model.Hollywood;
import com.AggregateFunction.model.Movie;

public class HibernateUtil {

	private static SessionFactory sessionFactory;

	public static SessionFactory getSessionFactory() {

		if (sessionFactory == null) {
			try {
				Configuration configuration = new Configuration();
				Properties properties = new Properties();
				properties.put(Environment.DRIVER, "com.microsoft.sqlserver.jdbc.SQLServerDriver");
				properties.put(Environment.URL,	"jdbc:sqlserver://localhost;databaseName=HibernateAssg_4_AggregateFunction;instanceName=SQLEXPRESS2019");
				properties.put(Environment.USER, "sa");
				properties.put(Environment.PASS, "password_123");
				properties.put(Environment.DIALECT, "org.hibernate.dialect.SQLServerDialect");
				properties.put(Environment.SHOW_SQL, "true");
				properties.put(Environment.FORMAT_SQL, "true");
				properties.put(Environment.HBM2DDL_AUTO, "create");

				configuration.setProperties(properties);
	
				configuration.addAnnotatedClass(Director.class);
				configuration.addAnnotatedClass(Hollywood.class);
				configuration.addAnnotatedClass(Movie.class);

				ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder()
						.applySettings(configuration.getProperties()).build();

				sessionFactory = configuration.buildSessionFactory(serviceRegistry);

			} catch (Exception e) {
				System.out.println(e);
			}
		}

		return sessionFactory;
	}
}

