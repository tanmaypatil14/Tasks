package com.AggregateFunction.daoImpl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import com.AggregateFunction.dao.MovieDao;
import com.AggregateFunction.util.HibernateUtil;

public class MovieDaoImpl implements MovieDao {
	
	private static SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
	private static Session session = sessionFactory.openSession();

	public int highestRevenueGenerated(String language) {
				
		Query query = session.createQuery("SELECT MAX(M.revenueInDollars) from Movie m where m.language = :language", Integer.class);
		query.setParameter("language", language);
		Integer result = (Integer) query.getSingleResult();
		
		session.close();
		return result;
	}

	public int lowestRevenueGenerated(String language) {

		Query query = session.createQuery("SELECT MIN(M.revenueInDollars) from Movie m where m.language = :language", Integer.class);
		query.setParameter("language", language);
		Integer result = (Integer) query.getSingleResult();
		
		session.close();
		return result;
	}

	public long sumofRevenues(String language) {

		Query query = session.createQuery("SELECT SUM(M.revenueInDollars) from Movie m where m.language = :language", Long.class);
		query.setParameter("language", language);
		Long result = (Long) query.getSingleResult();
		
		session.close();
		return result;
	}

	public double avaerageOfRevenue(String language) {

		Query query = session.createQuery("SELECT AVG(M.revenueInDollars) from Movie m where m.language = :language", Double.class);
		query.setParameter("language", language);
		Double result = (Double) query.getSingleResult();
		
		session.close();
		return result;
	}

	public long numberOfMovies(String language) {
		
		Query query = session.createQuery("SELECT COUNT(*) from Movie m where m.language = :language", Long.class);
		query.setParameter("language", language);
		Long result = (Long) query.getSingleResult();
		
		session.close();
		return result;
	}

	

}
