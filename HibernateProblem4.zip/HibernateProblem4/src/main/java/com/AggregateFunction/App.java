package com.AggregateFunction;

import com.AggregateFunction.dao.MovieDao;
import com.AggregateFunction.daoImpl.MovieDaoImpl;

public class App 
{
    public static void main( String[] args )
    {
         
    	MovieDao movieDao = new MovieDaoImpl();
    	System.out.println(movieDao.highestRevenueGenerated("English"));
    	
// ------------------------------------------------------------------------------------------
    	
//    	MovieDao movieDao = new MovieDaoImpl();
//    	System.out.println(movieDao.lowestRevenueGenerated("Hindi"));
    	
// ------------------------------------------------------------------------------------------
    	
//    	MovieDao movieDao = new MovieDaoImpl();
//    	System.out.println(movieDao.sumofRevenues("Hindi"));
    	
// ------------------------------------------------------------------------------------------
    	
//    	MovieDao movieDao = new MovieDaoImpl();
//    	System.out.println(movieDao.avaerageOfRevenue("Hindi"));
    	
// ---------------------------------------------------------------------------------------------
    	
//    	MovieDao movieDao = new MovieDaoImpl();
//    	System.out.println(movieDao.numberOfMovies("Hindi"));
//    	
    }
}
