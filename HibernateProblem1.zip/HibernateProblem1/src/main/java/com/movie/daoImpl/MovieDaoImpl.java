package com.movie.daoImpl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.movie.dao.MovieDao;
import com.movie.model.Movie;
import com.movie.util.HibernateUtil;

public class MovieDaoImpl implements MovieDao {
	
	private static SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
	private static Session session  = sessionFactory.openSession();

	public void addMovie(Movie movie) {

		try {

			session.beginTransaction();
			session.persist(movie);
			session.getTransaction().commit();
			System.out.println("Movie record has been successfully inserted");
			session.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public void deleteMovie(int movieId) {

		try {

			session.beginTransaction();
			Movie movie = session.load(Movie.class, movieId);
			session.delete(movie);
			session.getTransaction().commit();
			System.out.println("Record has been deleted successfully");
			session.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public void updateMovie(int movieId) {

		try {

			session.beginTransaction();
			Movie movie = session.load(Movie.class, movieId);
			movie.setRevenueInDollars(100000);
			session.merge(movie);
			session.getTransaction().commit();
			System.out.println("Record has been updated successfully");
			session.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public Movie getMovieDetails(int movieId) {

		Movie movie = session.get(Movie.class, movieId);
		
        session.close();
        
        return movie;
	}
}
