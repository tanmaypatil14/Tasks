package com.movie;

import java.util.Scanner;

import com.movie.daoImpl.MovieDaoImpl;
import com.movie.model.Movie;

public class App {
	public static void main(String[] args) {

		System.out.println("Enter 1 to insert a movie \nEnter 2 to delete a movie \nEnter 3 to update a movie \n"
				+ "Enter 4 to get a movie details ");

		Scanner scanner = new Scanner(System.in);
		Scanner scanner1 = new Scanner(System.in);
		int choice = scanner.nextInt();

		Movie movie = new Movie();
		MovieDaoImpl movieDaoImpl = new MovieDaoImpl();

		if (choice == 1) {

			System.out.println("Enter Movie Name");
			String movieName = scanner.next();
			
			System.out.println("Enter Movie Language");
			String movieLanguage = scanner1.nextLine();
			
			System.out.println("Enter Released in Year");
			int releasedInYear = scanner.nextInt();
			
			System.out.println("Enter Revenue in Dollars");
			int movieRevenue = scanner.nextInt();

			movie.setMovieName(movieName);
			movie.setLanguage(movieLanguage);
			movie.setReleasedIn(releasedInYear);
			movie.setRevenueInDollars(movieRevenue);

			movieDaoImpl.addMovie(movie);
			
		} else if (choice == 2) {
			System.out.println("Enter movie id you want to delete");
			int movieId = scanner.nextInt();

			movieDaoImpl.deleteMovie(movieId);
		} else if (choice == 3) {
			System.out.println("Enter movie ID you want to update");
			int movied = scanner.nextInt();

			movieDaoImpl.updateMovie(movied);
		} else if (choice == 4) {
			System.out.println("Enter movie ID you want to get");
			int movied = scanner.nextInt();
			System.out.println(movieDaoImpl.getMovieDetails(movied));
		}
		scanner.close();
		scanner1.close();
	}
}
